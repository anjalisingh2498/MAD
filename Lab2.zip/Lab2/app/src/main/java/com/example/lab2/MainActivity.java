package com.example.lab2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public Button button;
    ProgressBar progress;
    CountDownTimer t;
    float total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        progress = findViewById(R.id.progressBar2);

        progress.setMax(100);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progress.setVisibility(View.VISIBLE);
                long min = 10 * 1000;
                new CountDownTimer(min, 1000) {
                    @Override
                    public void onTick(long l) {
                        long a = min - l;
                        total = ((float) a / (float) min) * 100;
                        Log.e("Total", String.valueOf((a / min)));
                        progress.setProgress((int) total);
                    }

                    @Override
                    public void onFinish() {
                        AlertDialog.Builder d = new AlertDialog.Builder(MainActivity.this);
                        d.setTitle("Completed").setMessage("Loading as been completed").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MainActivity.this, "Done", Toast.LENGTH_LONG).show();
                            }
                        });
                        AlertDialog dialog = d.create();
                        dialog.show();
                    }
                }.start();
            }

        });

    }
}