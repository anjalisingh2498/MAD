package com.example.madlabprograms;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Lab4 extends AppCompatActivity {

    Button addButton;
    Button removeButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab4);
        addButton = findViewById(R.id.addButton);
        removeButton = findViewById(R.id.removeButton);

        MyFrag f1 = new MyFrag();

        addButton.setOnClickListener(v->{
                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                        ft.add(R.id.myframe,f1)
                        .commit();
        });

        removeButton.setOnClickListener(v->{
                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.remove(f1)
                    .commit();
        });
    }
}