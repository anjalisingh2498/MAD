package com.example.madlabprograms;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button lab1;
    Button lab2;
    Button lab3;
    Button lab4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lab1 = findViewById(R.id.lab1);
        lab1.setOnClickListener(v->{
            Intent intent = new Intent(getApplicationContext(), Lab1.class);
            startActivity(intent);
        });

        lab2 = findViewById(R.id.lab2);
        lab2.setOnClickListener(v->{
            Intent intent = new Intent(getApplicationContext(), Lab2.class);
            startActivity(intent);
        });

        lab3 = findViewById(R.id.lab3);
        lab3.setOnClickListener(v->{
            Intent intent = new Intent(getApplicationContext(), Lab3.class);
            startActivity(intent);
        });

        lab4 = findViewById(R.id.lab4);
        lab4.setOnClickListener(v->{
            Intent intent = new Intent(getApplicationContext(),Lab4.class);
            startActivity(intent);
        });
    }
}