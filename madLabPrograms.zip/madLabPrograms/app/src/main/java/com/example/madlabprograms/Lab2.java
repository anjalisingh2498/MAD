package com.example.madlabprograms;

import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Lab2 extends AppCompatActivity {

    private ProgressBar progressBar;
    private Button startButton;
    private TextView messageTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab2);

        progressBar = findViewById(R.id.progressBar);
        startButton = findViewById(R.id.startButton);
        messageTextView = findViewById(R.id.messageTextView);

        startButton.setOnClickListener(v -> {
            progressBar.setProgress(0);
            messageTextView.setText("Progress started...");

            new Handler(Looper.getMainLooper()).postDelayed(this::simulateProgress, 1000);
        });
    }

    private void simulateProgress() {
        final int maxProgress = 100;
        final int progressIncrement = 10;

        new Thread(() -> {
            for (int i = 0; i <= maxProgress; i += progressIncrement) {
                final int checkProgressFinished = i;
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                runOnUiThread(() -> {
                    progressBar.setProgress(checkProgressFinished);

                    if (checkProgressFinished == maxProgress) {
                        messageTextView.setText("Progress completed!");
                        showAlert();
                    } else {
                        messageTextView.setText("Progress: " + checkProgressFinished + "%");
                    }
                });
            }
        }).start();
    }

    private void showAlert() {
        new AlertDialog.Builder(this)
                .setTitle("Alert")
                .setMessage("Progress completed successfully!")
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .create()
                .show();
    }
}
