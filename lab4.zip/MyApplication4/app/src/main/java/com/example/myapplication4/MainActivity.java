package com.example.myapplication4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


   // Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn;
        btn =findViewById(R.id.btnclick);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn.setVisibility(View.INVISIBLE);
                Fragment fragment = new Fragment(R.layout.fragment_fragmentb);
                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                FragmentTransaction.replace(R.id.fragmentContainerView, fragment).commit();

                Toast.makeText(MainActivity.this, "Changed to Fragment1", Toast.LENGTH_SHORT).show();

            }
        });


    }
}